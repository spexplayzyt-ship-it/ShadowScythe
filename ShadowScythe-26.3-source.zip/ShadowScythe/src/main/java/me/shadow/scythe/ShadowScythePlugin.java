package me.shadow.scythe;

import java.util.Objects;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

public final class ShadowScythePlugin extends JavaPlugin implements Listener {
    private NamespacedKey scytheKey;

    @Override
    public void onEnable() {
        scytheKey = new NamespacedKey(this, "shadow_scythe");
        Bukkit.getPluginManager().registerEvents(this, this);
        Objects.requireNonNull(getCommand("scythe")).setExecutor((sender, command, label, args) -> {
            if (!(sender instanceof Player player)) {
                sender.sendMessage("Only a player can use this command.");
                return true;
            }
            if (!player.hasPermission("shadow_scythe.get")) {
                player.sendMessage("You don't have permission.");
                return true;
            }
            player.getInventory().addItem(createScythe());
            player.sendMessage("§5§lSHADOW SCYTHE §dhas been added to your inventory!");
            return true;
        });
        getLogger().info("ShadowScythe enabled.");
    }

    private ItemStack createScythe() {
        ItemStack item = new ItemStack(Material.NETHERITE_HOE);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName("§5§l☠ Shadow Scythe ☠");
        meta.setLore(java.util.List.of(
                "§7Left-click: §dTeleport where you aim",
                "§7Right-click: §cOne-shot target mob",
                "§7Shift + Right-click: §5Dark Soul Blast",
                "§8A weapon forged from the void"
        ));
        meta.getPersistentDataContainer().set(scytheKey, PersistentDataType.BYTE, (byte) 1);
        meta.setUnbreakable(true);
        item.setItemMeta(meta);
        return item;
    }

    private boolean isScythe(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return false;
        Byte marker = item.getItemMeta().getPersistentDataContainer().get(scytheKey, PersistentDataType.BYTE);
        return marker != null && marker == (byte) 1;
    }

    @EventHandler
    public void onUse(PlayerInteractEvent event) {
        Action action = event.getAction();
        if (action != Action.LEFT_CLICK_AIR && action != Action.LEFT_CLICK_BLOCK
                && action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) return;
        Player player = event.getPlayer();
        if (!isScythe(event.getItem())) return;
        event.setCancelled(true);

        if (action == Action.LEFT_CLICK_AIR || action == Action.LEFT_CLICK_BLOCK) {
            teleportToAim(player);
            return;
        }
        if (player.isSneaking()) {
            soulBlast(player);
        } else {
            oneShotTarget(player);
        }
    }

    private void teleportToAim(Player player) {
        World world = player.getWorld();
        RayTraceResult hit = world.rayTraceBlocks(player.getEyeLocation(), player.getEyeLocation().getDirection(),
                100.0, org.bukkit.FluidCollisionMode.NEVER, true);
        if (hit == null || hit.getHitBlock() == null) {
            player.sendMessage("§5The void cannot find a destination.");
            return;
        }
        Location destination = hit.getHitPosition().toLocation(world).add(0, 1.05, 0);
        destination.setDirection(player.getLocation().getDirection());
        if (!destination.getBlock().isPassable() || !destination.clone().add(0, 1, 0).getBlock().isPassable()) {
            player.sendMessage("§cDestination is blocked!");
            return;
        }
        world.spawnParticle(Particle.PORTAL, player.getLocation().add(0, 1, 0), 45, 0.45, 0.8, 0.45, 0.15);
        player.teleport(destination);
        world.spawnParticle(Particle.DRAGON_BREATH, destination, 55, 0.5, 0.8, 0.5, 0.04);
        world.playSound(destination, Sound.ENTITY_ENDERMAN_TELEPORT, 1.0f, 0.65f);
    }

    private void oneShotTarget(Player player) {
        Location eye = player.getEyeLocation();
        RayTraceResult hit = player.getWorld().rayTraceEntities(eye, eye.getDirection(), 80.0, 0.8,
                entity -> entity instanceof LivingEntity && !(entity instanceof Player));
        if (hit == null || hit.getHitEntity() == null) {
            player.sendMessage("§7Aim at a mob within 80 blocks.");
            return;
        }
        Entity target = hit.getHitEntity();
        if (target instanceof LivingEntity living) {
            Location at = living.getLocation().add(0, 1, 0);
            player.getWorld().spawnParticle(Particle.SOUL, at, 35, 0.45, 0.65, 0.45, 0.08);
            player.getWorld().playSound(at, Sound.ENTITY_WITHER_HURT, 1.0f, 0.7f);
            living.setHealth(0.0);
            player.sendMessage("§5☠ Soul claimed!");
        }
    }

    private void soulBlast(Player player) {
        Location center = player.getLocation().add(0, 0.8, 0);
        World world = player.getWorld();
        world.spawnParticle(Particle.EXPLOSION_EMITTER, center, 1);
        world.spawnParticle(Particle.SOUL_FIRE_FLAME, center, 240, 5.5, 2.0, 5.5, 0.12);
        world.spawnParticle(Particle.PORTAL, center, 300, 6.0, 2.5, 6.0, 0.3);
        world.playSound(center, Sound.ENTITY_GENERIC_EXPLODE, 2.0f, 0.55f);
        world.playSound(center, Sound.ENTITY_WARDEN_SONIC_BOOM, 1.5f, 0.7f);

        // Deliberately does not break blocks or damage the caster.
        for (Entity entity : world.getNearbyEntities(center, 8.0, 5.0, 8.0)) {
            if (entity instanceof LivingEntity living && !(entity instanceof Player)) {
                living.setHealth(0.0);
            }
        }
        player.sendMessage("§5§lDARK SOUL BLAST!");
    }
}
