SHADOW SCYTHE — PaperMC plugin source project
Target: Minecraft/Paper 26.3

ABILITIES
- Left-click: teleport to the block position you're aiming at (up to 100 blocks).
- Right-click: instantly kills the living entity you're aiming at (up to 80 blocks).
- Sneak + right-click: kills living entities in an 8-block radius. It does NOT break blocks or hurt the caster.
- The item is a named Netherite Hoe with a hidden persistent marker and unbreakable durability.

GET THE ITEM
Run /scythe in-game (permission shadow_scythe.get; default OP).

BUILD
This project requires JDK 25 and an internet connection.
1. Open this folder in IntelliJ IDEA with Gradle support, or use a computer with Gradle installed.
2. Run: gradle build
3. The plugin jar will be at: build/libs/ShadowScythe-1.0.0.jar

INSTALL ON A PAPER SERVER
1. Stop the server and make a backup.
2. Upload ShadowScythe-1.0.0.jar into the server's plugins/ folder.
3. Start the server.
4. Join as OP and run /scythe.

IMPORTANT
This is a Paper plugin, not a client mod. Players do not need to install anything.
The plugin source is supplied here; a compiled .jar is not included because this build environment does not have JDK 25 or access to Paper's Maven repository.
