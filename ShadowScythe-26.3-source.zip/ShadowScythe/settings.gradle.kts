rootProject.name = "ShadowScythe"
